/*
本插件集合由swimly整理于2014-07-07日，这只是基础版，还有其他常用特效，还希望大家加上去，然后分享到群共享，大家共同进步，取长补短！
插件所属：web前端页面开发
*/
/*经典版运动框架*/
function startMove(obj, json, fn) {
	clearInterval(obj.iTimer);
	var iCur = 0;
	var iSpeed = 0;
	obj.iTimer = setInterval(function() {
		var iBtn = true;
		for ( var attr in json ) {
			var iTarget = json[attr];
			if (attr == 'opacity') {
				iCur = Math.round(css( obj, 'opacity' ) * 100);
			} else {
				iCur = parseInt(css(obj, attr));
			}
			iSpeed = ( iTarget - iCur ) / 8;
			iSpeed = iSpeed > 0 ? Math.ceil(iSpeed) : Math.floor(iSpeed);
			
			if (iCur != iTarget) {
				iBtn = false;
				if (attr == 'opacity') {
					obj.style.opacity = (iCur + iSpeed) / 100;
					obj.style.filter = 'alpha(opacity='+ (iCur + iSpeed) +')';
				} else {
					obj.style[attr] = iCur + iSpeed + 'px';
				}
			}
		}
		if (iBtn) {
			clearInterval(obj.iTimer);
			fn && fn.call(obj);
		}
	}, 30);
}
/*-----------------------------------
获取元素css样式
*/
function css(obj, attr) {
	if (obj.currentStyle) {
		return obj.currentStyle[attr];
	} else {
		return getComputedStyle(obj, false)[attr];
	}
}
/*时间版运动框架*/
function sportTime(obj,json,times,fx,fn){
	if( typeof times == 'undefined' ){
		times = 400;
		fx = 'linear';
	}
	if( typeof times == 'string' ){
		if(typeof fx == 'function'){
			fn = fx;
		}
		fx = times;
		times = 400;
	}
	else if(typeof times == 'function'){
		fn = times;
		times = 400;
		fx = 'linear';
	}
	else if(typeof times == 'number'){
		if(typeof fx == 'function'){
			fn = fx;
			fx = 'linear';
		}
		else if(typeof fx == 'undefined'){
			fx = 'linear';
		}
	}
	var iCur = {};
	for(var attr in json){
		iCur[attr] = 0;
		if( attr == 'opacity' ){
			iCur[attr] = Math.round(getStyle(obj,attr)*100);
		}
		else{
			iCur[attr] = parseInt(getStyle(obj,attr));
		}
	}
	var startTime = now();
	clearInterval(obj.timer);
	obj.timer = setInterval(function(){
		var changeTime = now();
		var t = times - Math.max(0,startTime - changeTime + times);  //0到2000
		for(var attr in json){
			var value = Tween[fx](t,iCur[attr],json[attr]-iCur[attr],times);
			if(attr == 'opacity'){
				obj.style.opacity = value/100;
				obj.style.filter = 'alpha(opacity='+value+')';
			}
			else{
				obj.style[attr] = value + 'px';
			}
		}
		if(t == times){
			clearInterval(obj.timer);
			if(fn){
				fn.call(obj);
			}
		}
	},13);
	function getStyle(obj,attr){
		if(obj.currentStyle){
			return obj.currentStyle[attr];
		}
		else{
			return getComputedStyle(obj,false)[attr];
		}
	}
	function now(){
		return (new Date()).getTime();
	}
}
var Tween = {
	linear: function (t, b, c, d){  //匀速
		return c*t/d + b;
	},
	easeIn: function(t, b, c, d){  //加速曲线
		return c*(t/=d)*t + b;
	},
	easeOut: function(t, b, c, d){  //减速曲线
		return -c *(t/=d)*(t-2) + b;
	},
	easeBoth: function(t, b, c, d){  //加速减速曲线
		if ((t/=d/2) < 1) {
			return c/2*t*t + b;
		}
		return -c/2 * ((--t)*(t-2) - 1) + b;
	},
	easeInStrong: function(t, b, c, d){  //加加速曲线
		return c*(t/=d)*t*t*t + b;
	},
	easeOutStrong: function(t, b, c, d){  //减减速曲线
		return -c * ((t=t/d-1)*t*t*t - 1) + b;
	},
	easeBothStrong: function(t, b, c, d){  //加加速减减速曲线
		if ((t/=d/2) < 1) {
			return c/2*t*t*t*t + b;
		}
		return -c/2 * ((t-=2)*t*t*t - 2) + b;
	},
	elasticIn: function(t, b, c, d, a, p){  //正弦衰减曲线（弹动渐入）
		if (t === 0) { 
			return b; 
		}
		if ( (t /= d) == 1 ) {
			return b+c; 
		}
		if (!p) {
			p=d*0.3; 
		}
		if (!a || a < Math.abs(c)) {
			a = c; 
			var s = p/4;
		} else {
			var s = p/(2*Math.PI) * Math.asin (c/a);
		}
		return -(a*Math.pow(2,10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
	},
	elasticOut: function(t, b, c, d, a, p){    //正弦增强曲线（弹动渐出）
		if (t === 0) {
			return b;
		}
		if ( (t /= d) == 1 ) {
			return b+c;
		}
		if (!p) {
			p=d*0.3;
		}
		if (!a || a < Math.abs(c)) {
			a = c;
			var s = p / 4;
		} else {
			var s = p/(2*Math.PI) * Math.asin (c/a);
		}
		return a*Math.pow(2,-10*t) * Math.sin( (t*d-s)*(2*Math.PI)/p ) + c + b;
	},    
	elasticBoth: function(t, b, c, d, a, p){
		if (t === 0) {
			return b;
		}
		if ( (t /= d/2) == 2 ) {
			return b+c;
		}
		if (!p) {
			p = d*(0.3*1.5);
		}
		if ( !a || a < Math.abs(c) ) {
			a = c; 
			var s = p/4;
		}
		else {
			var s = p/(2*Math.PI) * Math.asin (c/a);
		}
		if (t < 1) {
			return - 0.5*(a*Math.pow(2,10*(t-=1)) * 
					Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
		}
		return a*Math.pow(2,-10*(t-=1)) * 
				Math.sin( (t*d-s)*(2*Math.PI)/p )*0.5 + c + b;
	},
	backIn: function(t, b, c, d, s){     //回退加速（回退渐入）
		if (typeof s == 'undefined') {
		   s = 1.70158;
		}
		return c*(t/=d)*t*((s+1)*t - s) + b;
	},
	backOut: function(t, b, c, d, s){
		if (typeof s == 'undefined') {
			s = 3.70158;  //回缩的距离
		}
		return c*((t=t/d-1)*t*((s+1)*t + s) + 1) + b;
	}, 
	backBoth: function(t, b, c, d, s){
		if (typeof s == 'undefined') {
			s = 1.70158; 
		}
		if ((t /= d/2 ) < 1) {
			return c/2*(t*t*(((s*=(1.525))+1)*t - s)) + b;
		}
		return c/2*((t-=2)*t*(((s*=(1.525))+1)*t + s) + 2) + b;
	},
	bounceIn: function(t, b, c, d){    //弹球减振（弹球渐出）
		return c - Tween['bounceOut'](d-t, 0, c, d) + b;
	},       
	bounceOut: function(t, b, c, d){
		if ((t/=d) < (1/2.75)) {
			return c*(7.5625*t*t) + b;
		} else if (t < (2/2.75)) {
			return c*(7.5625*(t-=(1.5/2.75))*t + 0.75) + b;
		} else if (t < (2.5/2.75)) {
			return c*(7.5625*(t-=(2.25/2.75))*t + 0.9375) + b;
		}
		return c*(7.5625*(t-=(2.625/2.75))*t + 0.984375) + b;
	},      
	bounceBoth: function(t, b, c, d){
		if (t < d/2) {
			return Tween['bounceIn'](t*2, 0, c, d) * 0.5 + b;
		}
		return Tween['bounceOut'](t*2-d, 0, c, d) * 0.5 + c*0.5 + b;
	}
}
/*-----------------------------------------------------------------------------------------*/
/*弹性导航
menuItem：导航li的class值、mask：ul下li遮罩层的class值、maskBox：遮罩li下导航列表的外层tagName、navBox：整个外层导航的id值
*/
function flexibleMenu(menuItem,mask,maskBox,navBox){
	var oBox=document.getElementById(navBox);
	var oMark = getElementsByClassName(oBox,mask,"li")[0];
	var aBox = oBox.getElementsByClassName(menuItem);
	var childUl = oMark.getElementsByTagName(maskBox)[0];
	var timer = null;
	var timer2 = null;
	var iSpeed = 0;
	for(var i=0;i<aBox.length;i++){
		aBox[i].onmouseover = function(){
			clearTimeout(timer2);
			startMove( this.offsetLeft );
		};
		
		aBox[i].onmouseout = function(){
			timer2 = setTimeout(function(){
				startMove( 0 );
			},100);
		};
	}
	oMark.onmouseover = function(){
		clearTimeout(timer2);
	};
	oMark.onmouseout = function(){
		timer2 = setTimeout(function(){
			startMove( 0 );
		},100);
	};
	function startMove(iTarget){
		clearInterval(timer);
		timer = setInterval(function(){
			iSpeed += (iTarget - oMark.offsetLeft)/6;
			iSpeed *= 0.75;
			if( Math.abs(iSpeed)<=1 && Math.abs(iTarget - oMark.offsetLeft)<=1 ){
				clearInterval(timer);
				oMark.style.left = iTarget + 'px';
				childUl.style.left = -iTarget + 'px';
				iSpeed = 0;
			}
			else{
				oMark.style.left = oMark.offsetLeft + iSpeed + 'px';
				childUl.style.left = - oMark.offsetLeft + 'px';
			}
		},30);
	}
}
/*----------------------------------------------*/
/*漂浮广告
obj:漂浮对象id、speedX:水平方向速度、speedY：垂直方向速度、time：运动时间
*/
function floatingAds(obj,speedX,speedY,time){
	var oDiv = document.getElementById(obj);
	
	var iSpeedX = speedX;
	var iSpeedY = speedY;
	
	startMove();
	
	function startMove(){
		oDiv.onmouseover=function(){
			clearInterval(timer);
		}
		oDiv.onmouseout=function(){
			clearInterval(timer);
			timer=setInterval(move,time);
		}
		var timer=setInterval(move,time);
		function move(){
			
			var L = oDiv.offsetLeft + iSpeedX;
			var T = oDiv.offsetTop + iSpeedY;
			
			if(T>document.documentElement.clientHeight - oDiv.offsetHeight){
				T = document.documentElement.clientHeight - oDiv.offsetHeight;
				iSpeedY *= -1;
			}
			else if(T<0){
				T = 0;
				iSpeedY *= -1;
			}
			
			if(L>document.documentElement.clientWidth - oDiv.offsetWidth){
				L = document.documentElement.clientWidth - oDiv.offsetWidth;
				iSpeedX *= -1;
			}
			else if(L<0){
				L = 0;
				iSpeedX *= -1;
			}
			
			oDiv.style.left = L + 'px';
			oDiv.style.top = T + 'px';
		}
	}
}
/*-------------------------------------------------------*/
/*反弹轮显一*/
function slideRebound(obj,drag){
	var oUl = document.getElementById(obj);
	var aLi = oUl.getElementsByTagName('li');
	var disX = 0;
	var downX = 0;
	var iNow = 0;
	var timer = null;
	var iSpeed = 0;
	var auto;
	function autoPlay(){
			oUl.onmouseover=function(){
				clearInterval(time);
			}
			oUl.onmouseout=function(){
				clearInterval(time);
				time=setInterval(auto,2000)
			}
			var time=setInterval(auto,2000)
			function auto(){
				if(iNow<aLi.length-1){
					iNow++;
			}else{
				iNow=0;
			}
				rebound( - iNow * aLi[0].offsetWidth  );
		}
	}
	if(auto){
		autoPlay();
	}else{
		autoPlay();
		oUl.onmousedown = function(ev){
			var ev = ev || window.event;
			disX = ev.clientX - oUl.offsetLeft;
			downX = ev.clientX;
			
			clearInterval(timer);
			
			document.onmousemove = function(ev){
				var ev = ev || window.event;
				oUl.style.left = ev.clientX - disX + 'px';
			};
			document.onmouseup = function(ev){
				document.onmousemove = null;
				document.onmouseup = null;
				var ev = ev || window.event;
				
				if( ev.clientX < downX ){
					//alert('←');
					if( iNow != aLi.length-1 ){
						iNow++;
					}
					
					rebound( - iNow * aLi[0].offsetWidth  );
				}
				else{
					//alert('→');
					
					if( iNow != 0 ){
						iNow--;
					}
					
					rebound( - iNow * aLi[0].offsetWidth  );
					
				}
				
			};
			return false;
		}
	};
	
	function rebound(iTarget){
		clearInterval(timer);
		timer = setInterval(function(){
			
			iSpeed += (iTarget - oUl.offsetLeft)/6;
			iSpeed *= 0.75;
			
			if( Math.abs(iSpeed)<=1 && Math.abs(iTarget - oUl.offsetLeft)<=1 ){
				clearInterval(timer);
				iSpeed = 0;
				oUl.style.left = iTarget + 'px';
			}
			else{
				oUl.style.left = oUl.offsetLeft + iSpeed + 'px';
			}
			
		},30);
	}
	
};
/*----------------------------------*/
/*可以随意拖动的并带有重力的框架*/
function gravity(obj,button){
	var oDiv = document.getElementById(obj);
	var button=getElementsByClassName(oDiv,"header","div")[0];
	var vaHeight=document.documentElement.clientHeight;
	var vaWidth=document.documentElement.clientWidth;
	oDiv.style.left=(vaWidth-oDiv.offsetWidth)/2+"px";
	oDiv.style.top=(vaHeight-oDiv.offsetHeight)/2+"px";
	var disX = 0;
	var disY = 0;
	var prevX = 0;
	var prevY = 0;
	var iSpeedX = 0;
	var iSpeedY = 9.8;
	
	var timer = null;
	
	button.onmousedown = function(ev){
		var ev = ev || window.event;
		disX = ev.clientX - oDiv.offsetLeft;
		disY = ev.clientY - oDiv.offsetTop;
		
		prevX = ev.clientX;
		prevY = ev.clientY;
		
		document.onmousemove = function(ev){
			var ev = ev || window.event;
			oDiv.style.left = ev.clientX - disX + 'px';
			oDiv.style.top = ev.clientY - disY + 'px';
			
			iSpeedX = ev.clientX - prevX;
			iSpeedY = ev.clientY - prevY;
			
			prevX = ev.clientX;
			prevY = ev.clientY;
			
		};
		document.onmouseup = function(){
			document.onmousemove = null;
			document.onmouseup = null;
			
			startMove();
			
		};
		return false;
	};
	
	function startMove(){
		clearInterval(timer);
		timer = setInterval(function(){
			
			iSpeedY += 3;
			
			var L = oDiv.offsetLeft + iSpeedX;
			var T = oDiv.offsetTop + iSpeedY;
			
			if(T>document.documentElement.clientHeight - oDiv.offsetHeight){
				T = document.documentElement.clientHeight - oDiv.offsetHeight;
				iSpeedY *= -1;
				iSpeedY *= 0.75;
				iSpeedX *= 0.75;
			}
			else if(T<0){
				T = 0;
				iSpeedY *= -1;
				iSpeedY *= 0.75;
			}
			
			if(L>document.documentElement.clientWidth - oDiv.offsetWidth){
				L = document.documentElement.clientWidth - oDiv.offsetWidth;
				iSpeedX *= -1;
				iSpeedX *= 0.75;
			}
			else if(L<0){
				L = 0;
				iSpeedX *= -1;
				iSpeedX *= 0.75;
			}
			
			oDiv.style.left = L + 'px';
			oDiv.style.top = T + 'px';
			
		},30);
	}
};
/*--------------------------------*/
/*鼠标经过图片放大效果*/
function imagefocus(box) {
	//在转换布局的，相对用户眼睛的位置保持不变
	//offsetLeft[Top];
	var oUl = document.getElementById(box);
	var aLi = oUl.getElementsByTagName('li');
	var arr = [];
	var zIndex = 1;
	for (var i=0; i<aLi.length; i++) {
		arr.push( {left: aLi[i].offsetLeft, top: aLi[i].offsetTop} );
	}
	for (var i=0; i<aLi.length; i++) {
		aLi[i].index = i;
		//在用js去设置css样式的时候：在同一个代码块中，有些css样式的设置的权限要高于其他的样式
		/*aLi[i].style.left = aLi[i].offsetLeft + 'px';
		aLi[i].style.top = aLi[i].offsetTop + 'px';*/
		aLi[i].style.left = arr[i].left + 'px';
		aLi[i].style.top = arr[i].top + 'px';
		aLi[i].style.position = 'absolute';
		aLi[i].style.margin = '0px';
		aLi[i].onmouseover = function() {
			this.style.background = 'green';
			this.style.zIndex = zIndex++;
			startMove( this, {
				width : 200,
				height : 200,
				left : arr[this.index].left - 50,
				top : arr[this.index].top - 50
			});
		}
		aLi[i].onmouseout = function() {
			startMove( this, {
				width : 100,
				height : 100,
				left : arr[this.index].left,
				top : arr[this.index].top
			});
		}
	}
}
/*----------------------------------------------------*/
/*动态留言板
wrap:最外层div、oInput：输入框，一般都是textarea的class、send：提交按钮的class、show：显示信息的ul的class
*/
function dynamicmessage(wrap,oInput,send,show) {
	var wrap=document.getElementById(wrap);
	var oContent = wrap.getElementsByClassName(oInput)[0]
	var oBtn =wrap.getElementsByClassName(send)[0]
	var oUl =wrap.getElementsByClassName(show)[0]
	oBtn.onclick = function() {
		var oLi = document.createElement('li');
		oLi.innerHTML = oContent.value;
		oContent.value="";
		if ( oUl.children[0] ) {
			oUl.insertBefore( oLi, oUl.children[0] );
		} else {
			oUl.appendChild( oLi );
		}
		//var iHeight = oLi.offsetHeight;
		var iHeight = parseInt( css(oLi, 'height') );
		oLi.style.height = '0px';
		oLi.style.opacity = '0';
		oLi.style.filter = 'alpha(opacity=0)';
		startMove(oLi, {
			height : iHeight,
			opacity : 100
		});
	}
}
/*---------------------------------------------------*/
/*返回顶部*/
function backtotop(obj) {
	var oDiv = document.getElementById(obj);
	var iTimer = null;
	var b = 0;
	setTop();
	window.onscroll = function() {
		console.log(2);
		if (b != 1) {//如果b=1那么，当前的scroll事件是被定时器所触发，如果不等于1，那么就是非定时器的其他任何一个操作触发该事件
			clearInterval(iTimer);
		}
		b = 2;
		setTop();
	}
	oDiv.onclick = function() {
		clearInterval(iTimer);
		var iCur = iSpeed = 0;
		iTimer = setInterval(function() {
			iCur = document.documentElement.scrollTop || document.body.scrollTop;
			iSpeed = Math.floor( ( 0 - iCur ) / 8 );
			if ( iCur == 0 ) {
				clearInterval(iTimer);
			} else {
				document.documentElement.scrollTop = document.body.scrollTop = iCur + iSpeed;
			}
			console.log(1);
			b = 1;
		}, 30);
	}
	function setTop() {
		var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
		oDiv.style.top = scrollTop + document.documentElement.clientHeight - oDiv.offsetHeight + 'px';
	}
}
/*-----------------------------------------------------*/
/*图片按需加载*/
function loadondemand(wrap) {
	var oUl = document.getElementById(wrap);
	var aImg = oUl.getElementsByTagName('img');
	showImage();
	window.onscroll = showImage;
	function showImage() {
		var scrollTop  = document.documentElement.scrollTop || document.body.scrollTop;
		for (var i=0; i<aImg.length; i++) {
			if ( !aImg[i].isLoad && getTop(aImg[i]) < scrollTop + document.documentElement.clientHeight ) {
				//alert(i);
				aImg[i].src = aImg[i].getAttribute('_src');
				aImg[i].isLoad = true;
			}
		}
	}
	function getTop(obj) {
		var iTop = 0;
		while(obj) {
			iTop += obj.offsetTop;
			obj = obj.offsetParent;
		}
		return iTop;
	}
}
/*抖动*/
function shake ( obj, attr, endFn ) {
	var pos = parseInt( getStyle(obj, attr) );			// 有隐患的
	var arr = [];			// 20, -20, 18, -18 ..... 0
	var num = 0;
	var timer = null;
	for ( var i=20; i>0; i-=2 ) {
		arr.push( i, -i );
	}
	arr.push(0);
	clearInterval( obj.shake );
	obj.shake = setInterval(function (){
		obj.style[attr] = pos + arr[num] + 'px';
		num++;
		if ( num === arr.length ) {
			clearInterval( obj.shake );
			endFn && endFn();
		}
	}, 50);
}
/*反弹运动框架*/
function rebound(iTarget){
		clearInterval(timer);
		timer = setInterval(function(){
			
			iSpeed += (iTarget - oUl.offsetLeft)/6;
			iSpeed *= 0.75;
			
			if( Math.abs(iSpeed)<=1 && Math.abs(iTarget - oUl.offsetLeft)<=1 ){
				clearInterval(timer);
				iSpeed = 0;
				oUl.style.left = iTarget + 'px';
			}
			else{
				oUl.style.left = oUl.offsetLeft + iSpeed + 'px';
			}
			
		},30);
	}
/*--------------------------------------------------------*/
/*getElementsByClassName兼容函数*/
function getElementsByClassName(parent,className,tagName){
		var aEls=parent.getElementsByTagName(tagName);
		var arr=[];
		for(var i=0;i<aEls.length;i++){
			/*if(aEls[i].className==className){
				arr.push(aEls[i]);
			}*/
			var aClassName=aEls[i].className.split(" ");
			for(var j=0;j<aClassName.length;j++){
				if(aClassName[j]==className){
					arr.push(aEls[i]);
					break;
				}
			}
		}
		return arr;
	}
/*获取样式*/
function getStyle ( obj, attr ) { 
	return obj.currentStyle?obj.currentStyle[attr] : getComputedStyle( obj )[attr];
 }
/*firstchild第一个子元素*/
function first(parent){
	return parent.firstElementChild || oUl.firstChild;
}
function last(parent){
	return oUl.lastElementChild || oUl.lastChild;
}
function next(parent){
	return oFirst.nextElementSibling || oFirst.nextSibling;
}
function prev(parent){
	return oLast.previousElementSibling || oLast.previousSibling;
}
/*获取元素坐标*/
function getPos(obj) {
		
		var pos = {left:0, top:0};
		
		while (obj) {
			pos.left += obj.offsetLeft;
			pos.top += obj.offsetTop;
			obj = obj.offsetParent;
		}
		return pos;
	}
/*拖拽*/
function drag(obj) {
		obj.onmousedown = function(ev) {
			var ev = ev || event;
			var disX = ev.clientX - this.offsetLeft;
			var disY = ev.clientY - this.offsetTop;
			if ( obj.setCapture ) {
				obj.setCapture();
			}
			document.onmousemove = function(ev) {
				var ev = ev || event;
				obj.style.left = ev.clientX - disX + 'px';
				obj.style.top = ev.clientY - disY + 'px';
			}
			document.onmouseup = function() {
				document.onmousemove = document.onmouseup = null;
				//释放全局捕获 releaseCapture();
				if ( obj.releaseCapture ) {
					obj.releaseCapture();
				}
			}
			return false;
		}
	}